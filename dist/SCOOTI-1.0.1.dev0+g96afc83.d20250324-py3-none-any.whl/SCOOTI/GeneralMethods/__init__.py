#__init__.py
# import essentail modules for shortening the code for other modules
from .stat_tests import *
from .MatplotProp import CanvasStyle, PltProps, Significance
from .findSigGenes import *


#__all__ = [
#        "hypergeom_test",
#        "ranksumtest",
#        "CanvasStyle",
#        "PltProps",
#        "Significance",
#        "findSigGenes"
#        ]
