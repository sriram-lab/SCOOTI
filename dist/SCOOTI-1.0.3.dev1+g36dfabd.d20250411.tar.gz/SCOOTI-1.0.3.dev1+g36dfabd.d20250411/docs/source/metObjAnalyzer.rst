metObjAnalyzer.py
=================


Core Analysis Module
--------------------
.. automodule:: SCOOTI.metObjAnalyzer
    :members:
