# Causal Structured Variational Archetypal Regressor (CSVAr-VAE)
# + DataLoader + Coefficient Output + 5-Fold CV

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, TensorDataset
from sklearn.model_selection import KFold
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import seaborn as sns
from scipy.spatial import ConvexHull
from tqdm import tqdm

# ---- Dataset from Pandas ----
class GOFluxDataset(Dataset):
    def __init__(self, X_df: pd.DataFrame, y_df: pd.DataFrame):
        self.X = torch.tensor(X_df.values, dtype=torch.float32)
        self.y = torch.tensor(y_df.values, dtype=torch.float32)
        self.X_cols = X_df.columns.tolist()
        self.y_cols = y_df.columns.tolist()

    def __len__(self):
        return self.y.shape[1]  # each GO term is one sample (column-wise)

    def __getitem__(self, idx):
        return self.X.T, self.y[:, idx]  # shape: (n_features, n_samples), (n_samples,)


class Encoder(nn.Module):
    def __init__(self, input_dim, latent_dim):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc_mu = nn.Linear(128, latent_dim)
        self.fc_logvar = nn.Linear(128, latent_dim)

    def forward(self, x):
        h = F.relu(self.fc1(x))
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        beta = mu + eps * std  # Gaussian β (not constrained to simplex)
        return beta, mu, logvar

class ArchetypeDecoder(nn.Module):
    def __init__(self, X_fixed):
        super().__init__()
        self.X_fixed = nn.Parameter(X_fixed, requires_grad=False)

    def forward(self, beta):
        return torch.matmul(beta, self.X_fixed)

class ArchVAE(nn.Module):
    def __init__(self, input_dim, latent_dim, X_fixed):
        super().__init__()
        self.encoder = Encoder(input_dim, latent_dim)
        self.decoder = ArchetypeDecoder(X_fixed)
        self.pareto_hull_points = None  # Pareto front vertices (convex hull)

    def forward(self, y):
        beta, mu, logvar = self.encoder(y)
        y_hat = self.decoder(beta)
        return y_hat, beta, mu, logvar

    def reconstruction_loss(self, y, y_hat):
        return F.mse_loss(y_hat, y, reduction='mean')

    def kl_divergence(self, mu, logvar):
        return -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())

    def pareto_geometry_loss(self, beta):
        if self.pareto_hull_points is None:
            return torch.tensor(0.0, device=beta.device)
        pareto_tensor = self.pareto_hull_points.detach().to(beta.device)  # ensure no gradient flows into Pareto front itself
        dists = torch.cdist(beta, pareto_tensor)
        min_dist = torch.min(dists, dim=1).values
        return torch.mean(min_dist)

# ---- Pareto Hull ----
def update_pareto_hull(model, dataloader):
    all_beta = []
    with torch.no_grad():
        for X_batch, y_batch in dataloader:
            beta, _, _ = model.encoder(y_batch)
            all_beta.append(beta.cpu())
    beta_stack = torch.cat(all_beta, dim=0).numpy()
    try:
        hull = ConvexHull(beta_stack)
        hull_points = torch.tensor(beta_stack[hull.vertices], dtype=torch.float32)
        model.pareto_hull_points = hull_points
    except Exception as e:
        print("Convex hull update failed:", e)
        model.pareto_hull_points = None


# ---- Training loop ----
def train_model(model, dataloader, optimizer, epochs=100, kl_weight=0.01, geo_weight=0.01):
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        for X_batch, y_batch in dataloader:
            optimizer.zero_grad()
            y_hat, beta, mu, logvar = model(y_batch)
            recon_loss = model.reconstruction_loss(y_batch, y_hat)
            kl = model.kl_divergence(mu, logvar)
            geo = model.pareto_geometry_loss(beta)
            loss = recon_loss + kl_weight * kl + geo_weight * geo
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        print(f"Epoch {epoch+1}, Loss: {total_loss/len(dataloader):.4f}")
        update_pareto_hull(model, dataloader)


# ---- Coefficient Inference ----
def infer_coefficients(model, y_tensor, go_cols, x_cols):
    model.eval()
    with torch.no_grad():
        beta, _, _ = model.encoder(y_tensor)
        coef_df = pd.DataFrame(beta.cpu().numpy().T, index=x_cols, columns=go_cols)
    return coef_df

# ---- Cross-Validation ----
def run_fold_cv(X_df, y_df, latent_dim=32, epochs=50, batch_size=32):
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    all_coefs = []
    for fold, (train_idx, test_idx) in tqdm(enumerate(kf.split(y_df.columns))):
        print(f"\nFold {fold+1}")
        y_train = y_df.iloc[:, train_idx]
        dataset = GOFluxDataset(X_df, y_train)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

        X_fixed = torch.tensor(X_df.values, dtype=torch.float32)
        model = ArchVAE(input_dim=y_df.shape[0], latent_dim=latent_dim, X_fixed=X_fixed)
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

        train_model(model, dataloader, optimizer, epochs=epochs)

        # Infer coefficients on training set GO terms
        y_tensor = torch.tensor(y_train.values, dtype=torch.float32)
        coef_df = infer_coefficients(model, y_tensor, y_train.columns, X_df.columns)
        all_coefs.append(coef_df)

    return all_coefs  # list of 5 coef_df (GO_terms × objectives)


# ---- Visualization ----
def visualize_beta(beta_tensor, labels=None):
    beta_np = beta_tensor.detach().cpu().numpy()
    pca = PCA(n_components=2)
    beta_pca = pca.fit_transform(beta_np)
    plt.figure(figsize=(6, 5))
    sns.scatterplot(x=beta_pca[:, 0], y=beta_pca[:, 1], hue=labels, palette='tab10' if labels is not None else None)
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.title("PCA of Inferred β")
    plt.tight_layout()
    plt.show()

# ---- Example Usage ----
# model = CSVArVAE(input_dim=3757, latent_dim=1000, X_fixed=X_tensor)

