import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import KFold
import pandas as pd
import numpy as np
from tqdm import tqdm

class FluxDataset(Dataset):
    def __init__(self, X: pd.DataFrame, y_col: np.ndarray):
        self.X = torch.tensor(X.values, dtype=torch.float32)
        self.y = torch.tensor(y_col.reshape(-1, 1), dtype=torch.float32)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

class MLPRegressor(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc_beta = nn.Linear(128, input_dim)

    def forward(self, X):
        h = F.relu(self.fc1(X))
        beta = F.relu(self.fc_beta(h))
        return beta

def train_model(model, dataloader, optimizer, epochs=100, l1_weight=1e-4, entropy_weight=1e-4):
    model.train()
    for epoch in range(epochs):
        for X_batch, y_batch in dataloader:
            optimizer.zero_grad()
            beta = model(X_batch)  # beta: (batch_size, n_features)
            y_hat = torch.sum(X_batch * beta, dim=1, keepdim=True)  # predicted flux: (batch_size, 1)
            mse_loss = F.mse_loss(y_hat, y_batch)
            l1_loss = beta.abs().mean()
            entropy = - (F.softmax(beta, dim=1) * F.log_softmax(beta, dim=1)).sum(dim=1).mean()
            loss = mse_loss + l1_weight * l1_loss + entropy_weight * entropy
            loss.backward()
            optimizer.step()

def infer_beta(model, X_tensor):
    model.eval()
    with torch.no_grad():
        beta = model(X_tensor)
        return beta.mean(dim=0).cpu().numpy()

class CVWrapper:
    def __init__(self, epochs=50, batch_size=32, verbose=True):
        self.epochs = epochs
        self.batch_size = batch_size
        self.verbose = verbose
        self.coef_df = None

    def _train_one_fold(self, X_df, y_col, train_idx):
        X_train = X_df.iloc[train_idx, :]
        y_train = y_col[train_idx]
        dataset = FluxDataset(X_train, y_train)
        dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        model = MLPRegressor(input_dim=X_train.shape[1])
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
        train_model(model, dataloader, optimizer, epochs=self.epochs, l1_weight=1e-4, entropy_weight=1e-4)
        X_tensor = torch.tensor(X_train.values, dtype=torch.float32)
        return infer_beta(model, X_tensor)

    def run_fold_cv(self, X: pd.DataFrame, y: pd.DataFrame, k=5):
        self.feature_names = X.columns.tolist()
        self.target_names = y.columns.tolist()
        all_coefs = []
        for j in tqdm(range(y.shape[1])):
            #if self.verbose and j % 100 == 0:
            #    print(f"Fitting target {j+1}/{y.shape[1]}")
            y_col = y.iloc[:, j].values
            kf = KFold(n_splits=k, shuffle=True, random_state=42)
            fold_coefs = []
            for train_idx, _ in kf.split(X):
                weights = self._train_one_fold(X, y_col, train_idx)
                fold_coefs.append(weights)
            avg_weights = np.mean(np.stack(fold_coefs), axis=0)
            all_coefs.append(avg_weights)
        coef_matrix = np.stack(all_coefs, axis=1)
        self.coef_df = pd.DataFrame(coef_matrix, index=self.feature_names, columns=self.target_names)
        return self.coef_df

