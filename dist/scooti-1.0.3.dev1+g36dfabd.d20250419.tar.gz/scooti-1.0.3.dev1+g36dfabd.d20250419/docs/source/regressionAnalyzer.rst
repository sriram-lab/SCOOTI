regressionAnalysis.py
=====================


Core Analysis Module
--------------------
.. automodule:: SCOOTI.regressionAnalyzer
    :members:
