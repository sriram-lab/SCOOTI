.. SCOOTI documentation master file, created by
   sphinx-quickstart on Thu Dec  7 01:46:03 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SCOOTI's documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   regressionAnalyzer
   metObjAnalyzer
   quickstart
   scootisettings
   advancedusage

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
